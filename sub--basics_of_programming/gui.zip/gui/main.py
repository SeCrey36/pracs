import gui


def main():
    gui.main_window()

if __name__ == '__main__':
    main()
